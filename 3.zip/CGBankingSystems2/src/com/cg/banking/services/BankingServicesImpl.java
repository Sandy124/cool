package com.cg.banking.services;

import java.util.HashMap;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transactions;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDaoImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberexception;
import com.cg.banking.util.BankingDBUtil;

public class BankingServicesImpl implements BankingServices{
	private AccountDAO accountDao=new AccountDaoImpl();
	TransactionDAO transaction = new TransactionDAOImpl();
	int miniBalnce=500;
	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServiceDownException {
		if(accountType.equalsIgnoreCase("Savings")||accountType.equalsIgnoreCase("current")) {
		Account account=new Account(accountType,initBalance);
		account.transactions = new HashMap<>();
		account=accountDao.save(account);
		return account.getAccountNo();
		}
		else
		throw new InvalidAccountTypeException("Invalid Entry of account");
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServiceDownException, AccountBlockedException {
		Account customers=null;
		customers=accountDao.findOne(accountNo);
		if(customers==null)
			throw new AccountNotFoundException("Account Not Found ");
		else if(customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException("Account is Blocked");
		else 
			customers.setAccountBalance(customers.getAccountBalance()+amount);
		transaction.save(customers.getAccountNo(), new Transactions(amount,"Deposit"));
		return customers.getAccountBalance();	
	}


	@Override
	public String toString() {
		return "BankingServicesImpl [accountDao=" + accountDao + "]";
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, long pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberexception, BankingServiceDownException, AccountBlockedException {
		Account customers=accountDao.findOne(accountNo);
		if(customers==null)
			throw new AccountNotFoundException("Account Number Does Not Exist");
		if(pinNumber==customers.getPinNumber()){
			customers.setAccountBalance(customers.getAccountBalance()-amount);
			transaction.save(customers.getAccountNo(),new Transactions(amount,"Withdraw"));
			return customers.getAccountBalance();
		}
		else
			throw new InvalidPinNumberexception("Invalid Pin Number");
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServiceDownException {
		Account account=accountDao.findOne(accountNo);
		if(account==null)throw new AccountNotFoundException("Account number nahi hai hamare paas");
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServiceDownException {

		return accountDao.findAll();
	}

	@Override
	public List<Transactions> getAccountAllTransactions(long accountNo) throws BankingServiceDownException, AccountNotFoundException {

		return transaction.findAll();
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServiceDownException, AccountNotFoundException, AccountBlockedException {
		Account account=accountDao.findOne(accountNo);
		if(account==null)throw new AccountNotFoundException("Account number nahi hai hamare paas");
		return null;
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, long pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberexception,
			BankingServiceDownException, AccountBlockedException {
		/*withdrawAmount(accountNoFrom, transferAmount, pinNumber);
		depositAmount(accountNoTo, transferAmount);
		Transactions transaction = new Transactions();
		Account account = accountDao.findOne(accountNoFrom);
		transaction.setTransactionType(BankingDBUtil.getFUND_TRANSFER_TYPE());
		Integer transactionId=BankingDBUtil.getTRANSACTION_ID();
		transaction.setTransactionId(transactionId);
		transaction.setAmount(transferAmount);
		account.transactions.put(transactionId,transaction);*/
		Account customerTo=getAccountDetails(accountNoTo);
		Account customerFrom=getAccountDetails(accountNoFrom);

		if(customerFrom.getAccountBalance()-transferAmount<=miniBalnce)
			throw new InsufficientAmountException("Your Account Balance is Too Low");
		else if(customerFrom.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberexception("Pin Number Does not match");
		else
			customerFrom.setAccountBalance(customerFrom.getAccountBalance()-transferAmount);
		transaction.save(customerFrom.getAccountNo(),new Transactions(transferAmount,"Fund Transfer"));
		depositAmount(customerTo.getAccountNo(), transferAmount);
		return true;
	}



}
