package com.cg.banking.beans;
import java.util.HashMap;
import java.util.List;
public class Account {

	private long pinNumber;
	private String accountType,accountStatus;
	private float accountBalance;
	public HashMap<Integer,Transactions>transactions;	
	private long accountNo;
	public Transactions transaction;
@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", pinNumber=" + pinNumber + ", accountType=" + accountType
				+ ", accountStatus=" + accountStatus + ", accountBalance=" + accountBalance + ", transactions="
				+ transactions + "]";
	}


public Account(String accountType, float accountBalance) {
	super();
	this.accountType = accountType;
	this.accountBalance = accountBalance;
}



public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}
public long getPinNumber() {
	return pinNumber;
}
public void setPinNumber(long pinNumber) {
	this.pinNumber = pinNumber;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public String getAccountStatus() {
	return accountStatus;
}
public void setAccountStatus(String accountStatus) {
	this.accountStatus = accountStatus;
}
public float getAccountBalance() {
	return accountBalance;
}
public void setAccountBalance(float accountBalance) {
	this.accountBalance = accountBalance;
}
public HashMap<Integer,Transactions> getTransactions() {
	return transactions;
}
public void setTransactions(HashMap<Integer,Transactions> transactions) {
	this.transactions = transactions;
}


}
