package com.cg.banking.exceptions;

public class BankingServiceDownException extends Exception{

}
