package com.cg.banking.exceptions;

public class InvalidAccountTypeException extends Exception {
	public InvalidAccountTypeException(String message) {
		super(message);
	}
}
