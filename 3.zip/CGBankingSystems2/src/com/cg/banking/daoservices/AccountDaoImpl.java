package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingDBUtil;


public class AccountDaoImpl implements AccountDAO{

	@Override
	public Account save(Account account) {
		account.setAccountNo(BankingDBUtil.getACCOUNT_NUMBER());
		account.setPinNumber(BankingDBUtil.PIN_NUMBER());
		account.setAccountStatus("Active");
		long y=account.getPinNumber();
		BankingDBUtil.account.put(account.getAccountNo(), account);
		
				return account;
	}

	
	
	@Override
	public boolean update(Account account) {
		// TODO Auto-generated method stub
		return false;
	}
	

	
	
	@Override
	public String toString() {
		return "AccountDaoImpl [findAll()=" + findAll() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

	
	
	@Override
	public Account findOne(long accountNo) {
		// TODO Auto-generated method stub
		return BankingDBUtil.account.get(accountNo);
	}

	
	
	@Override
	public List<Account> findAll() {
		ArrayList account=new ArrayList<>(BankingDBUtil.account.values());
		return account;
	}
}
