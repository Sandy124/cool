package com.capgemini.xyz.dao;

import java.util.Map;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.util.LoanUtil;

public class LoanDAOImpl  implements LoanDAO{

	@Override
	public Map<Integer, Customer> customerEntry(Customer cust) {
					
		cust.setCustID(LoanUtil.getCustomerId());
		LoanUtil.cust.put((int) cust.getCustID(),cust);
		
		return    LoanUtil.getCollection()  ;
	}

	@Override
	public Map<Integer, Loan> LoanEntry(Loan loan) {
	
		loan.setLoanID(LoanUtil.getLoan_Id());
				LoanUtil.loan.put((int) loan.getLoanID(), loan);
		return     LoanUtil.getCollection1()  ;
	}
}