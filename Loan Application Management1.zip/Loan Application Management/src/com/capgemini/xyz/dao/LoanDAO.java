package com.capgemini.xyz.dao;

import java.util.Map;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public interface LoanDAO {

public Map<Integer,Customer>customerEntry(Customer cust);
     public Map<Integer,Loan>LoanEntry(Loan loan);
     
       

}

