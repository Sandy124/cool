package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.service.LoanService;
import com.capgemini.xyz.service.LoanServiceImpl;

public class ExecuterMain {

	public static void main(String[] args) {
 
	    long custID;
	    String custName;
        String address;
		 long mobile;
		String email;
		
		LoanService loanservice=new LoanServiceImpl();
		
		System.out.println("Enter the details Of Customer");
		Scanner in=new Scanner (System.in);
		
		System.out.println("Enter the  Customer Name");
	    		 custName=in.next();
	    		 
	    		 System.out.println("Enter the  Customer Address");
	    		 address=in.next();
	   	    	
	    		 System.out.println("Enter the  Customer Email ID");
	    		 email=in.next();
	}

}
