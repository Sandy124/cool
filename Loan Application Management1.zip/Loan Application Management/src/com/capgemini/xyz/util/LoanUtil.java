package com.capgemini.xyz.util;

import java.util.HashMap;
import java.util.Map;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public class LoanUtil {

	public static long Loan_Id=100;

	public static Map<Integer, Loan> loan= new HashMap<>();
	
	public static Map<Integer,Customer> cust= new HashMap<>();
	
	
	public static long getCustomerId() {
		
		return (long) (Math.random()*10);
	}
	
	public static long getLoan_Id() {
		return ++ Loan_Id;
	}
public static HashMap<Integer,Customer>getCollection(){
		
		return (HashMap<Integer, Customer>) cust;
}
		public static HashMap<Integer,Loan>getCollection1()
		{
		return (HashMap<Integer, Loan>) loan;
}
}